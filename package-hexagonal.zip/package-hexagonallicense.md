# The license

Copyright (c) :author_name <:author_email>

...Add your license text here...
