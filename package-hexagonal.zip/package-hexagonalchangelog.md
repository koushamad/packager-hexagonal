# Changelog

All notable changes to `:uc:package` will be documented in this file.

## Version 1.0

### Added
- Everything
