<div>
    Price: {{ $ping->ip }}
</div>
